# Business Problem
As a marketing agency, our primary objective is to maximize the return on investment (ROI) for our clients' advertising campaigns. We have conducted two ad campaigns, one on Facebook and the other on AdWords, and we need to determine which platform yields better results in terms of clicks, conversions, and overall cost-effectiveness. By identifying the most effective platform, we can allocate our resources more efficiently and optimize our advertising strategies to deliver better outcomes for our clients.

# Research Question
#Which ad platform is more effective in terms of conversions, clicks, and overall cost-effectiveness?
-for this We calculate three key performance metrics -
 Click-Through Rate (CTR),Conversion Rate, & Cost per Click (CPC)


```python
#Importing Libraries

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as st
import seaborn as sns
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error
import warnings
warnings.filterwarnings('ignore')
```


```python
#loading the dataset
df = pd.read_csv(r"C:\Users\DELL\Downloads\PROJECTS\ABmarketing_campaign.csv")
```


```python
# data overview
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Facebook Ad Campaign</th>
      <th>Facebook Ad Views</th>
      <th>Facebook Ad Clicks</th>
      <th>Facebook Ad Conversions</th>
      <th>Cost per Facebook Ad</th>
      <th>Facebook Click-Through Rate (Clicks / View)</th>
      <th>Facebook Conversion Rate (Conversions / Clicks)</th>
      <th>Facebook Cost per Click (Ad Cost / Clicks)</th>
      <th>AdWords Ad Campaign</th>
      <th>AdWords Ad Views</th>
      <th>AdWords Ad Clicks</th>
      <th>AdWords Ad Conversions</th>
      <th>Cost per AdWords Ad</th>
      <th>AdWords Click-Through Rate (Clicks / View)</th>
      <th>AdWords Conversion Rate (Conversions / Click)</th>
      <th>AdWords Cost per Click (Ad Cost / Clicks)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1/1/2019</td>
      <td>FB_Jan19</td>
      <td>2116</td>
      <td>18</td>
      <td>8</td>
      <td>$126</td>
      <td>0.83%</td>
      <td>42.73%</td>
      <td>$7.14</td>
      <td>AW_Jan19</td>
      <td>4984</td>
      <td>59</td>
      <td>5</td>
      <td>$194</td>
      <td>1.18%</td>
      <td>8.40%</td>
      <td>$3.30</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1/2/2019</td>
      <td>FB_Jan19</td>
      <td>3106</td>
      <td>36</td>
      <td>12</td>
      <td>$104</td>
      <td>1.15%</td>
      <td>34.04%</td>
      <td>$2.91</td>
      <td>AW_Jan19</td>
      <td>4022</td>
      <td>71</td>
      <td>6</td>
      <td>$75</td>
      <td>1.77%</td>
      <td>7.80%</td>
      <td>$1.05</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1/3/2019</td>
      <td>FB_Jan19</td>
      <td>3105</td>
      <td>26</td>
      <td>8</td>
      <td>$102</td>
      <td>0.84%</td>
      <td>31.45%</td>
      <td>$3.89</td>
      <td>AW_Jan19</td>
      <td>3863</td>
      <td>44</td>
      <td>4</td>
      <td>$141</td>
      <td>1.13%</td>
      <td>9.59%</td>
      <td>$3.23</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1/4/2019</td>
      <td>FB_Jan19</td>
      <td>1107</td>
      <td>27</td>
      <td>9</td>
      <td>$71</td>
      <td>2.45%</td>
      <td>34.76%</td>
      <td>$2.62</td>
      <td>AW_Jan19</td>
      <td>3911</td>
      <td>49</td>
      <td>5</td>
      <td>$141</td>
      <td>1.26%</td>
      <td>11.08%</td>
      <td>$2.86</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1/5/2019</td>
      <td>FB_Jan19</td>
      <td>1317</td>
      <td>15</td>
      <td>7</td>
      <td>$78</td>
      <td>1.10%</td>
      <td>47.59%</td>
      <td>$5.38</td>
      <td>AW_Jan19</td>
      <td>4070</td>
      <td>55</td>
      <td>7</td>
      <td>$133</td>
      <td>1.36%</td>
      <td>12.22%</td>
      <td>$2.40</td>
    </tr>
  </tbody>
</table>
</div>




```python
#rows and columns count of the dataset
df.shape
```




    (365, 17)




```python
#datatypes of the colums
df.dtypes
```




    Date                                               object
    Facebook Ad Campaign                               object
    Facebook Ad Views                                   int64
    Facebook Ad Clicks                                  int64
    Facebook Ad Conversions                             int64
    Cost per Facebook Ad                               object
    Facebook Click-Through Rate (Clicks / View)        object
    Facebook Conversion Rate (Conversions / Clicks)    object
    Facebook Cost per Click (Ad Cost / Clicks)         object
    AdWords Ad Campaign                                object
    AdWords Ad Views                                    int64
    AdWords Ad Clicks                                   int64
    AdWords Ad Conversions                              int64
    Cost per AdWords Ad                                object
    AdWords Click-Through Rate (Clicks / View)         object
    AdWords Conversion Rate (Conversions / Click)      object
    AdWords Cost per Click (Ad Cost / Clicks)          object
    dtype: object




```python
#converting date to datetime
df['Date'] = pd.to_datetime(df['Date'])
```


```python
# descriptive stats of the campaigns
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Facebook Ad Views</th>
      <th>Facebook Ad Clicks</th>
      <th>Facebook Ad Conversions</th>
      <th>AdWords Ad Views</th>
      <th>AdWords Ad Clicks</th>
      <th>AdWords Ad Conversions</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>365</td>
      <td>365.000000</td>
      <td>365.000000</td>
      <td>365.000000</td>
      <td>365.00000</td>
      <td>365.000000</td>
      <td>365.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2019-07-02 00:00:00</td>
      <td>2179.687671</td>
      <td>44.049315</td>
      <td>11.742466</td>
      <td>4717.19726</td>
      <td>60.383562</td>
      <td>5.980822</td>
    </tr>
    <tr>
      <th>min</th>
      <td>2019-01-01 00:00:00</td>
      <td>1050.000000</td>
      <td>15.000000</td>
      <td>5.000000</td>
      <td>3714.00000</td>
      <td>31.000000</td>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2019-04-02 00:00:00</td>
      <td>1656.000000</td>
      <td>35.000000</td>
      <td>10.000000</td>
      <td>4247.00000</td>
      <td>49.000000</td>
      <td>5.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2019-07-02 00:00:00</td>
      <td>2202.000000</td>
      <td>43.000000</td>
      <td>12.000000</td>
      <td>4711.00000</td>
      <td>60.000000</td>
      <td>6.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2019-10-01 00:00:00</td>
      <td>2717.000000</td>
      <td>54.000000</td>
      <td>13.000000</td>
      <td>5190.00000</td>
      <td>73.000000</td>
      <td>7.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2019-12-31 00:00:00</td>
      <td>3320.000000</td>
      <td>73.000000</td>
      <td>19.000000</td>
      <td>5760.00000</td>
      <td>89.000000</td>
      <td>9.000000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>NaN</td>
      <td>618.074639</td>
      <td>12.140559</td>
      <td>2.924786</td>
      <td>561.11406</td>
      <td>14.368225</td>
      <td>1.628106</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.dtypes
```




    Date                                               datetime64[ns]
    Facebook Ad Campaign                                       object
    Facebook Ad Views                                           int64
    Facebook Ad Clicks                                          int64
    Facebook Ad Conversions                                     int64
    Cost per Facebook Ad                                       object
    Facebook Click-Through Rate (Clicks / View)                object
    Facebook Conversion Rate (Conversions / Clicks)            object
    Facebook Cost per Click (Ad Cost / Clicks)                 object
    AdWords Ad Campaign                                        object
    AdWords Ad Views                                            int64
    AdWords Ad Clicks                                           int64
    AdWords Ad Conversions                                      int64
    Cost per AdWords Ad                                        object
    AdWords Click-Through Rate (Clicks / View)                 object
    AdWords Conversion Rate (Conversions / Click)              object
    AdWords Cost per Click (Ad Cost / Clicks)                  object
    dtype: object



# Comparing Campaigns performance


```python
#distribution of the clicks and conversion
plt.figure(figsize=(15,6))
plt.subplot(1,2,1)
plt.title("Facebook Ad Clicks")
sns.histplot(df["Facebook Ad Clicks"],bins = 7 , edgecolor = 'k', kde = True)
plt.subplot(1,2,2)
plt.title("Facebook Ad Conversions")
sns.histplot(df["Facebook Ad Conversions"],bins = 7 , edgecolor = 'k', kde = True)
plt.show()  

plt.figure(figsize=(15,6))
plt.subplot(1,2,1)
plt.title("AdWords Ad Clicks")
sns.histplot(df["AdWords Ad Clicks"],bins = 7 , edgecolor = 'k', kde = True)
plt.subplot(1,2,2)
plt.title("AdWords Ad Conversions")
sns.histplot(df["AdWords Ad Conversions"],bins = 7 , edgecolor = 'k', kde = True)
plt.show()  
```


    
![png](output_11_0.png)
    



    
![png](output_11_1.png)
    



#All the histogram are showing some what symmetrical shape. This symmetrical shape suggests that the number of clicks and conversions is relatively evenly distributed. In other words, there are not many clicks or conversions that are outliers on either the high or low end.

#How frequently do we observe days with high numbers of conversions compared to days with low numbers of conversions?


```python
# creating function to calculate the category for the conversion
def create_category(conversion_col):
    category = []
    for conversion in df[conversion_col]:
        if conversion < 6:
            category.append('less than 6')
        elif 6 <= conversion < 11:
            category.append('6-10')
        elif 11 <= conversion < 16:
            category.append('10-15')
        else:
            category.append('more than 15')
    return category

# applying function of different campaign's conversions
df['Facebook Conversion Category'] = create_category('Facebook Ad Conversions')
df['AdWords Conversion Category'] = create_category('AdWords Ad Conversions')
        
```


```python
df[['Facebook Ad Conversions','Facebook Conversion Category','AdWords Ad Conversions','AdWords Ad Conversions']].head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Facebook Ad Conversions</th>
      <th>Facebook Conversion Category</th>
      <th>AdWords Ad Conversions</th>
      <th>AdWords Ad Conversions</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>8</td>
      <td>6-10</td>
      <td>5</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>12</td>
      <td>10-15</td>
      <td>6</td>
      <td>6</td>
    </tr>
    <tr>
      <th>2</th>
      <td>8</td>
      <td>6-10</td>
      <td>4</td>
      <td>4</td>
    </tr>
    <tr>
      <th>3</th>
      <td>9</td>
      <td>6-10</td>
      <td>5</td>
      <td>5</td>
    </tr>
    <tr>
      <th>4</th>
      <td>7</td>
      <td>6-10</td>
      <td>7</td>
      <td>7</td>
    </tr>
  </tbody>
</table>
</div>




```python
df['Facebook Conversion Category'].value_counts()
```




    Facebook Conversion Category
    10-15           189
    6-10            128
    more than 15     47
    less than 6       1
    Name: count, dtype: int64




```python
facebook = pd.DataFrame(df['Facebook Conversion Category'].value_counts()).reset_index().rename(columns = {'Facebook Conversion Category':'Category'})
facebook
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Category</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>10-15</td>
      <td>189</td>
    </tr>
    <tr>
      <th>1</th>
      <td>6-10</td>
      <td>128</td>
    </tr>
    <tr>
      <th>2</th>
      <td>more than 15</td>
      <td>47</td>
    </tr>
    <tr>
      <th>3</th>
      <td>less than 6</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
df['AdWords Conversion Category'].value_counts()
```




    AdWords Conversion Category
    6-10           209
    less than 6    156
    Name: count, dtype: int64




```python
adwords = pd.DataFrame(df['AdWords Conversion Category'].value_counts()).reset_index().rename(columns = {'AdWords Conversion Category':'Category'})
adwords
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Category</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>6-10</td>
      <td>209</td>
    </tr>
    <tr>
      <th>1</th>
      <td>less than 6</td>
      <td>156</td>
    </tr>
  </tbody>
</table>
</div>




```python

category_df = pd.merge(facebook, adwords, on = 'Category', how = 'outer').fillna(0)
category_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Category</th>
      <th>count_x</th>
      <th>count_y</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>10-15</td>
      <td>189</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>6-10</td>
      <td>128</td>
      <td>209.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>less than 6</td>
      <td>1</td>
      <td>156.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>more than 15</td>
      <td>47</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
category_df = category_df.iloc[[2,1,0,3]]
category_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Category</th>
      <th>count_x</th>
      <th>count_y</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2</th>
      <td>less than 6</td>
      <td>1</td>
      <td>156.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>6-10</td>
      <td>128</td>
      <td>209.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>10-15</td>
      <td>189</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>more than 15</td>
      <td>47</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
X_axis = np.arange(len(category_df))
X_axis
```




    array([0, 1, 2, 3])




```python
# Bar chart to compare conversion categories
plt.figure(figsize=(15, 6))
plt.bar(X_axis - 0.2, category_df['count_x'], width=0.4, label='Facebook')
plt.bar(X_axis + 0.2, category_df['count_y'], width=0.4, label='AdWords')
plt.xticks(X_axis, category_df['Category'])
plt.xlabel("Conversion Category")
plt.ylabel("Number of Days")
plt.title("Frequency of Daily Conversions by Conversion Categories", fontsize=15)
plt.legend(fontsize=15)
plt.show()
```


    
![png](output_23_0.png)
    



```python
#The data suggests Facebook had more frequent higher conversion days than AdWords, which either had very low conversion rates (less than 6) or moderate ones (6 - 10).
#There is a significant variance in the number of high-conversion days between two different campaigns.
#The absence of any days with conversions between 10 - 15 and more than 15 in AdWords indicates a need to review what strategies were changed or what external factors could have influenced these numbers.
```

# Do more clicks on the ad really to more sales?


```python
plt.figure(figsize = ( 15,6))
plt.subplot(1,2,1)
plt.title('Facebook')
sns.scatterplot(x = df['Facebook Ad Clicks'],y= df['Facebook Ad Conversions'],color = '#03989E')
plt.xlabel('Clicks')
plt.ylabel('Conversion')
plt.subplot(1,2,2)
plt.title('Adwords')
sns.scatterplot(x = df['AdWords Ad Clicks'],y= df['AdWords Ad Conversions'],color = '#03989E')
plt.xlabel('Clicks')
plt.ylabel('conversions')
plt.show()
```


    
![png](output_26_0.png)
    



```python
facebook_corr = df[['Facebook Ad Clicks', 'Facebook Ad Conversions']].corr()
facebook_corr
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Facebook Ad Clicks</th>
      <th>Facebook Ad Conversions</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Facebook Ad Clicks</th>
      <td>1.000000</td>
      <td>0.873775</td>
    </tr>
    <tr>
      <th>Facebook Ad Conversions</th>
      <td>0.873775</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
AdWords_corr = df[['AdWords Ad Clicks', 'AdWords Ad Conversions']].corr()
AdWords_corr
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>AdWords Ad Clicks</th>
      <th>AdWords Ad Conversions</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>AdWords Ad Clicks</th>
      <td>1.000000</td>
      <td>0.447993</td>
    </tr>
    <tr>
      <th>AdWords Ad Conversions</th>
      <td>0.447993</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
print('Correlation Coeff \n ------------------------')
print('Facebook :',round(facebook_corr.values[0,1],2))
print('AdWords :',round(AdWords_corr.values[0,1],2))      
```

    Correlation Coeff 
     ------------------------
    Facebook : 0.87
    AdWords : 0.45
    


```python
#Facebook Ads (Correlation = 0.87)
# 1 There is a strong positive relationship between Facebook ad clicks and sales.
# 2 When Facebook ad clicks increase, sales also increase significantly, showing that Facebook ads are very effective.
# AdWords Ads (Correlation = 0.45)
# 1 There is a moderate positive relationship between AdWords ad clicks and sales.
# 2 AdWords ads help increase sales, but their impact is weaker than Facebook ads and may depend on other factors.
```

# Hypothesis Testing
Hypothesis: Advertising on Facebook will result in a greater number of conversions compared to advertising on AdWords.

Null Hypothesis (H0): There is no difference in the number of conversions between Facebook and AdWords, or the number of conversions from AdWords is greater than or equal to those from Facebook.

H0: µ_Facebook ≤ µ_AdWords

Alternate Hypothesis (H1): The number of conversions from Facebook is greater than the number of conversions from AdWords.

H1: µ_Facebook > µ_AdWord

```python
print('Mean Conversion \n ---------')
print('Facebook :',round(df['Facebook Ad Conversions'].mean(),2))
print('AdWords :',round(df['AdWords Ad Conversions'].mean(),2))
```

    Mean Conversion 
     ---------
    Facebook : 11.74
    AdWords : 5.98
    


```python
t_test,p_value = st.ttest_ind(a = df['Facebook Ad Conversions'], b=df['AdWords Ad Conversions'], equal_var = False)
print('\nT statistic',t_test,'\np-value',p_value)

# Comparing the p value with the significance of 5% or 0.05
if p_value<0.05:
    print("\np-value is less than significance value, Reject the null hypothesis")
else:
    print("\np-value is greater than significance value, Accept the null hypothesis")
```

    
    T statistic 32.88402060758184 
    p-value 9.348918164530465e-134
    
    p-value is less than significance value, Reject the null hypothesis
    

#Facebook ads perform significantly better than AdWords, with a much higher average number of conversions (11.74 vs 5.98), indicating stronger effectiveness in driving conversions.

#The very large T-statistic (32.88) and extremely small p-value (≈ 0) show a statistically significant difference between Facebook and AdWords conversions, strongly rejecting the null hypothesis.

#Business implication: Facebook should be prioritized for marketing investment, with increased budget and optimization efforts to maximize conversion performance.

# Regression Analysis

#What will happen when i do go with the Facebook Ad? How many Facebook ad conversion can i expect given a certain number of facebook ad clicks?


```python
# independent variable
x= df[['Facebook Ad Clicks']]

#dependent variable
y= df[['Facebook Ad Conversions']]

# initializing and fitting Linear Regression model
reg_model = LinearRegression()
reg_model.fit(x,y)
prediction = reg_model.predict(x)

#model evaluation
r2 = r2_score(y,prediction)*100
mse = mean_squared_error(y, prediction)
print('Accuracy R2 score):', round(r2,2),'%')
print('Mean Squared Error:',round(mse,2))
```

    Accuracy R2 score): 76.35 %
    Mean Squared Error: 2.02
    


```python
# Plotting linear regression
plt.figure(figsize=(8, 6))
sns.scatterplot(x=df['Facebook Ad Clicks'], y=df['Facebook Ad Conversions'], color='#03989E', label='Actual data points')
plt.plot(df['Facebook Ad Clicks'], prediction, color='#A62372', label='Best fit line')
plt.legend()
plt.show()
```


    
![png](output_39_0.png)
    



```python
print(f'For {50} Clicks, Expected Conversion : {round(reg_model.predict([[50]]).item(),2)}')
print(f'For {80} Clicks, Expected Conversion : {round(reg_model.predict([[80]]).item(),2)}')
```

    For 50 Clicks, Expected Conversion : 13.0
    For 80 Clicks, Expected Conversion : 19.31
    

#The model has a reasonably good predictive power, with an R2 score of 76.35%. This suggests that it can effectively predict Facebook ad conversions based on the number of Facebook ad clicks.

#With the insights provided by the Linear Regression model, businesses can make informed decisions about resource allocation, budget planning, and campaign optimization.

#For instance, knowing the expected number of Facebook ad conversions based on a certain number of Facebook ad clicks can help in setting realistic campaign goals, optimizing ad spend, and assessing the ROI of Facebook advertising efforts.


```python

```
